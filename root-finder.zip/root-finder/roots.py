import math

def rootFinder(a,b,c):
    discriminant = (b*b) - (4*(a*c))
    if discriminant < 0:
        print('roots not possible ')
    else:
        positiveRoot(a,b, discriminant)
        negativeRoot(a,b, discriminant)

def positiveRoot(a,b, discriminant):
    positive_root = (-b + math.sqrt(discriminant))/ (2*a)
    print(f'positive_root: {positive_root}')

def negativeRoot(a,b,discriminant):
    negative_root = (-b - math.sqrt(discriminant))/ (2*a)
    print(f'negative_root: {negative_root}')


