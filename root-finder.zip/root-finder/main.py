import roots
value_of_a = int(input('Enter a: '))
value_of_b = int(input('Enter b: '))
value_of_c = int(input('Enter c: '))

if __name__ == '__main__':
    roots.rootFinder(value_of_a, value_of_b, value_of_c)